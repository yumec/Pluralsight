# CSharpBP-Basics
Materials for the "C# Best Practices: Improving on the Basics" course
